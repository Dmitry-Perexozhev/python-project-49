### Hexlet tests and linter status:
[![Actions Status](https://github.com/Dmitry-Perexozhev/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Dmitry-Perexozhev/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/94eeb5b753f2748e5579/maintainability)](https://codeclimate.com/github/Dmitry-Perexozhev/python-project-49/maintainability)
